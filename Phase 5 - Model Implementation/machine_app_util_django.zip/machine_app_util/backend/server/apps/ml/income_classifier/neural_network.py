# file backend/server/apps/ml/income_classifier/neural_network.py
import joblib
import pandas as pd
import numpy as np 
import spacy
import pickle
import en_core_web_sm
nlp = spacy.load('en_core_web_sm')
import re
import string
import nltk
nltk.download('stopwords')
import unicodedata
from bs4 import BeautifulSoup
import os 
dir_path = os.path.dirname(os.path.realpath(__file__))
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

def evaluate_the_model(NN):
    df= pd.read_csv(r'''E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\backend\server\apps\research/final_cleaned_data.csv''', converters={"preprocess_data": eval})

    X_train, X_test, y_train, y_test = train_test_split(df.preprocess_data, df.hatespeech, test_size = 0.10, random_state = 25)
    X_train, X_valid, y_train, y_valid = train_test_split(X_train, y_train, test_size = 0.10, random_state = 25)

    y_pred = NN.predict(np.array(X_test.iloc[0:]))
    y_pred= np.argmax(y_pred, axis=1)
    y_pred

    
    print(classification_report(y_test[0:], y_pred))


class NeuralNetwork:
    def __init__(self):
        print("dir_path: ", dir_path)
        print("Reached here1")
        path_to_artifacts = "E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\\backend\server\\apps\\research"
        print("Reached here2")
        # filename_model= open(path_to_artifacts + "\\nn_model_update.joblib","rb")
        # self.model= pickle.Unpickler(filename_model, pickle.load(filename_model), fix_imports = True, encoding = "ASCII", errors = "strict")
        self.model = joblib.load(path_to_artifacts + "\\nn_model_update.joblib")
        # evaluate_the_model(self.model)
        print("Reached here3")

        self.preprocess= joblib.load(path_to_artifacts + "\preprocess_model.joblib")
        

    def preprocessing_for_requests(self, input_data):
        return {"clean_data": self.preprocess.preprocess_data(input_data)}

    def preprocessing(self, input_data):
        return self.preprocess.preprocess_data(input_data)

    def predict(self, input_data):
        return self.model.predict(input_data)

    def postprocessing(self, input_data):
        
        # return {"label":input_data , "status": "OK"}
        return {"label": np.argmax(input_data), "status": "OK"}

    def compute_prediction(self, input_data):
        try:
            input_data = self.preprocessing(input_data)
            # return {"preprocessed_data": input_data, "status": "OK"}
            prediction = self.predict(input_data)[0]  # only one sample
            prediction = self.postprocessing(prediction)
        except Exception as e:
            return {"status": "Error", "message": str(e)}

        return prediction