#!/usr/bin/env python
# coding: utf-8

# In[5]:


import pandas as pd
import numpy as np
import re
import string
import nltk
import unicodedata
from bs4 import BeautifulSoup

# In[11]:


import spacy
import en_core_web_sm
nlp = spacy.load('en_core_web_sm')

class feature_engineer:
    
    def expand_contracted_words(self,textlist):
        textstring= " ".join(textlist)
        textstring= re.sub(r"\'s"," ",textstring)
        textstring= re.sub(r"\'ve"," have ",textstring)    
        textstring= re.sub(r"\'ll"," will ",textstring)    
        textstring= re.sub(r"\n't"," not ",textstring)   
        textstring= re.sub(r"\'s"," ",textstring)    
        textstring= re.sub(r"i'm"," i am ",textstring)    
        textstring= re.sub(r"\'re"," are ",textstring)   
        textstring= re.sub(r"\'d"," would ",textstring) 
        return textstring.split()

    def remove_mention_punctuation(self,textlist): 
        #punctuation characters to be removed 
        punc_except_exclamation= set(string.punctuation) - set('!')
        no_punct=[word for word in textlist if word not in list(punc_except_exclamation)]
        textstring= " ".join(no_punct)
        textstring= re.sub(r"@[A-Za-z0-9_]+"," ",textstring) #remove mention
        return textstring.split()
    
    def remove_extra_characters(self,textlist):
        textstring= " ".join(textlist)
        textstring= re.sub(r"\s{2,}"," ",textstring)
        textstring= re.sub(r"(\w)\1{2,}", r"\1\1", textstring)
        return textstring.split()
    
    def convert_english_numerical(self,textlist):
        textstring= " ".join(textlist)
        textstring= re.sub(r"([0-9]+)k",r"\g<1>000" ,textstring)
        textstring= re.sub(r"([0-9]+)M",r"\g<1>000000" ,textstring)
        textstring= re.sub(r"([0-9]+)B",r"\g<1>000000000" ,textstring)
        return textstring.split()

    def tokenize(self,text):
        split=re.split(r"[^A-Za-z0-9*@!]",text) 
        return split
    
    def remove_stopwords(self,text):
        stopword = nltk.corpus.stopwords.words('english')
        text=[word for word in text if word not in stopword]
        return text
    
    def remove_accented_chars(self,text):
        joined_text = " ".join(text)
        new_text = unicodedata.normalize('NFKD', joined_text).encode('ascii', 'ignore').decode('utf-8', 'ignore')
        split_text = new_text.split(' ')
        return split_text
    
        # function to remove HTML tags
    def remove_html_tags(self,text):
        joined_text = " ".join(text)
        new_text= BeautifulSoup(joined_text, 'html.parser').get_text()
        split_text = new_text.split(' ')
        return split_text
    
    def remove_numbers(self,text):
        # define the pattern to keep
        joined_text = " ".join(text)
        pattern = r'[^a-zA-Z.,!?/:;\"\'\s]'
        new_text = re.sub(pattern, '', joined_text)
        split_text = new_text.split(' ')
        return split_text 
    

    def get_lem(self,text):
        text= " ".join(text)
        text = nlp(text)
        text = ' '.join([word.lemma_ if word.lemma_ != '-PRON-' else word.text for word in text])
        return text.split()
    
    def get_stem(self,text):
        stemmer = nltk.porter.PorterStemmer()
        text = ' '.join([stemmer.stem(word) for word in text.split()])
        return text.split()
    
    def preprocess_data(self,text):
        print(text)
        
        text= re.sub(r'https?://[A-Za-z0-9./]+','url', text)
        text= self.tokenize(text.lower())
        text= self.remove_mention_punctuation(text)
        text= self.remove_stopwords(text)
        text= self.convert_english_numerical(text)
        text= self.remove_accented_chars(text)
        text= self.remove_html_tags(text)
        text= self.remove_numbers(text)
        text= self.expand_contracted_words(text)
        text= self.remove_extra_characters(text)
        text= self.get_lem(text)
        return text


# In[12]:


import joblib
preproess_model= feature_engineer()
joblib.dump(preproess_model, "preprocess_model.joblib", compress=True)


# In[13]:


import joblib
preprocess_load= joblib.load("preprocess_model.joblib")
clean_data=preprocess_load.preprocess_data("hi I hate in but 556 I hate gays too much")
clean_data


# In[ ]:




