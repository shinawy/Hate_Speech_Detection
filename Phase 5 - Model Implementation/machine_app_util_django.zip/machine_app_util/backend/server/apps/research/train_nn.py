import numpy as np
import pandas as pd
import json
from sklearn.model_selection import train_test_split
from apps.research import AAAnn
from apps.research import preproces_data_class

import joblib


    
    
def train_save_nn():
    df= pd.read_csv(r'''E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\backend\server\apps\research\final_cleaned_data.csv''', converters={"preprocess_data": eval})

    X_train, X_test, y_train, y_test = train_test_split(df.preprocess_data, df.hatespeech, test_size = 0.20, random_state = 25)
   

    with open(r'''E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\backend\server\apps\research\freq_dic_encoded.txt''', 'r') as freq_file:
        encoded_words= json.load(freq_file)
    encoded_words
    
    train_data = (np.array(X_train), np.array(y_train))

    NN = NeuralNetwork(encoded_words, lr=0.5)
    embedding = layer(len(encoded_words),13, "word_embedding", activation= "tanh")
    hidden_layer = layer(13,5, "hidden_layer", activation="relu")
    output_layer = layer(5,1, "output_layer", activation="sigmoid")
    NN.add(embedding)
    NN.add(hidden_layer)
    NN.add(output_layer)
    train_data = (np.array(X_train), np.array(y_train))

    NN.fit(train_data, batch_size=1000, epochs = 10) 
    joblib.dump(NN, r'''E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\backend\server\apps\research/nn_model_update.joblib''', compress=True)
    return NN 

def preprocess_data_dump():
    feature_engineer= preproces_data_class.feature_engineer()
    joblib.dump(feature_engineer, r'''E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\backend\server\apps\research/preprocess_model.joblib''', compress=True)
    return feature_engineer