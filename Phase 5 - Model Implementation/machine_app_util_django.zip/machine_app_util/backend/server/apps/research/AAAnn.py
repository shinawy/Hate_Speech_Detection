#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
### Don't mind about this 
import warnings
warnings.filterwarnings('ignore')
###


# In[13]:


import json
with open('freq_dict_sorted.txt', 'r') as freq_file:
     freq_words= json.load(freq_file)
freq_words
all_words= freq_words.keys()
len(all_words)


# In[26]:


import json
def create_dict_for_encoding(freq_dict, file_output):
    encoded_dic = {}
    index = 0
    for key in freq_dict.keys():
        encoded_dic[key]= index
        index=index+1
    
    # writing the dict to a file for easier reading 
    json_dump= json.dumps(encoded_dic)
    json_file= open(file_output, "w")
    json_file.write(json_dump)
    json_file.close()
    
    return encoded_dic


# In[27]:


encoded_freq_words= create_dict_for_encoding(freq_words, "freq_dic_encoded.txt")
len(encoded_freq_words.keys())


# # Loading the Data

# In[47]:


df= pd.read_csv("./final_cleaned_data.csv", converters={"preprocess_data": eval})
df


# In[48]:


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(df.preprocess_data, df.hatespeech, test_size = 0.10, random_state = 25)
X_train, X_valid, y_train, y_valid = train_test_split(X_train, y_train, test_size = 0.10, random_state = 25)


# In[49]:


X_train.shape


# # Loading the encoded dict for words

# In[30]:


import json
with open('freq_dic_encoded.txt', 'r') as freq_file:
     encoded_words= json.load(freq_file)
encoded_words


# In[6]:




# In[244]:


class layer():
    def __init__(self,n_input,n_output, name, activation="sigmoid", weight_init= "uniform"):
        self.n_input = n_input
        self.n_output = n_output
        self.activation = self.get_activations()[activation]
        self.act_name = activation
        
        self.name= name

        
        # Trying different weight initializations
        if weight_init == "hnormal":
            self.W = np.random.randn(self.n_output,self.n_input)*np.sqrt(2/self.n_input)
            self.b = np.random.randn(self.n_output,1)*np.sqrt(2/self.n_input)
        elif weight_init == "normal":
            self.W = np.random.randn(0, 1, (self.n_output,self.n_input))
            self.b = np.random.randn(0, 1, (self.n_output,1))
        elif weight_init == "uniform":
            self.W = np.random.uniform(-0.05,0.05,(self.n_output,self.n_input))
            self.b = np.random.uniform(-0.05,0.05,(self.n_output,1))
            
        
        self.dW = np.zeros_like(self.W)
        self.db = np.zeros_like(self.b)

        self.Z = None
        self.X = None

        
    def sigmoid(self, z):
        return (1/(1+np.exp(-1*z)))

    def _diff_sigmoid(self, z):
        sig = self.sigmoid(z)
        return sig * (1-sig)
    
    def _leaky_relu(self, z):
        return np.maximum(z, -0.001 * z)
    
    def _diff_leaky_relu(self, z):
        leaky_relu= self._leaky_relu(z)
        return np.multiply(leaky_relu, np.ones_like(leaky_relu) - leaky_relu)
    
    # Hyperbolic Tangent (htan) Activation Function
    def _tanh(self,x):
        return(np.exp(x) - np.exp(-x))/(np.exp(x) + np.exp(-x))

    # htan derivative
    def _diff_tanh(self,x):
        return np.multiply(self._tanh(x), np.ones_like(self._tanh(x)) - self._tanh(x))


    def get_activations(self):
        return {"sigmoid":self.sigmoid, "relu": self._leaky_relu, "tanh": self._tanh}

    def get_activations_diff(self):
        return {"sigmoid":self._diff_sigmoid, "relu": self._diff_leaky_relu, "tanh": self._diff_tanh}


    def zeroing_delta(self):
        self.dW = np.zeros_like(self.W)
        self.db = np.zeros_like(self.b)

    def _set_target(self, t):
        self.target = t

    def forward(self,Ai):
        z =  np.add(np.dot(self.W,Ai),self.b)

        A = self.activation(z)
       
        
        self.Z = z
        self.Ai = Ai
        return A

    def backward(self,inp):
        
        act_diff = self.get_activations_diff()[self.act_name](self.Z)
        
#         tmp = inp * act_diff
        tmp= np.multiply(inp,act_diff)

#         bet = tmp @ self.Ai.T # vector of 1s
        bet= np.dot(tmp, self.Ai.T);

     
        
        e = np.ones((self.Ai.shape[1],1))
        db = np.dot(tmp ,e)
#         print("db shape: ",end='')
#         print(db.shape)
        
        self.dW = self.dW + bet
        self.db = self.db + db
    
        return np.dot(self.W.T , tmp)
    


# In[343]:


class NeuralNetwork():
    
    
    def __init__(self,all_words, lr=0.5):
        self.layers = []
        self.all_words = all_words
        self.learning_rate=lr
        

     ## Binary Cross Entropy
    def imp_binary_cross_log(self,y_true, y_pred):
        y_logp= np.multiply(y_true, np.log(y_pred)) + np.multiply((np.ones_like(y_true)- y_true), np.log(np.ones_like (y_pred)- y_pred))
#         print("y_logp shape:::{}, ytrue shape: {}, ypred shape: {}".format(y_logp.shape, y_true.shape, y_pred.shape))
        return y_logp

    def imp_binary_cross_sum(self,y_true, y_pred):
        y_logp= self.imp_binary_cross_log(y_true, y_pred)
        return (-1/y_true.size)* y_logp.sum()
    ####
    
    ## focal Loss 
    def imp_focal_loss_log(self, y_true, y_pred, alpha=0.25, gamma=2):
        
        y_true= y_true.reshape(y_true.shape[0], y_pred.shape[1])
        comp_ytrue= (np.ones_like(y_true)- y_true)
        comp_yhat= (np.ones_like(y_pred)- y_pred)
        
        first_term= alpha * np.multiply(np.multiply(y_true, np.log(y_pred)), comp_yhat**gamma)
        second_term= (1- alpha) * np.multiply(np.multiply(comp_ytrue, np.log(comp_yhat)), y_pred**gamma)
        
        focal_loss= first_term + second_term
#         print("y_logp focal_loss:::{} shape: {}, shape[0]: {}".format(focal_loss[0], focal_loss.shape, focal_loss[0].shape))
        return focal_loss
    
    def imp_focal_loss_sum(self, y_true, y_pred, alpha=0.25, gamma=2):
        focal_loss= self.imp_focal_loss_log(y_true, y_pred,alpha, gamma)
        return ((-1)/y_true.size)* (focal_loss.sum())
   
        
        
    def transform_words(self, x):
        encoding = np.zeros(len(self.all_words))
        i = 0
        for word in x:
            if word in self.all_words:
                encoding[self.all_words[word]] = 1
        return encoding.astype(np.int8)
    
    def add(self,layer):
        self.layers.append(layer)
    
    def forward(self,input_):
        X_words = input_
        for layer in self.layers:
            X_words= layer.forward(X_words)


        return X_words.T
    
    def backward(self,input_):
        gd = input_
        for layer in self.layers[::-1]:
            gd = layer.backward(gd)

            
            
    def zeroing(self):
        for layer in self.layers:
            layer.zeroing_delta()
            

    def batch(self,x,y,bs):
        x = x.copy()
        y = y.copy()
        rem = x.shape[0] % bs

        for i in range(0,x.shape[0],bs):
            yield (x[i:i+bs],y[i:i+bs])
        
        if rem !=0:
            yield (x[x.shape[0]-rem:],y[x.shape[0]-rem:] )

    def fit(self,train_data, batch_size=32, epochs=5):
        x_train= train_data[0]
        y_train= train_data[1]
        no_of_batches_train = np.ceil(x_train.shape[0]/batch_size)
       
        
        
        # Two moving averages as per ADAM optimizer concept
        m = []
        v = []
        
        count=0
        for i in range(epochs):
             
            # initializing the moving averages as per ADAM optimizer concept
            for layer in self.layers:
                w = np.zeros_like(layer.W)
                b = np.zeros_like(layer.b)
                m.append([w,b])
                v.append([w,b])
                
            print()
            print("Epoch {}/{}".format(i+1,epochs))
            j=0
            
            data = self.batch(x_train,y_train,batch_size)
            print("length of data is {}".format(count))
            losses = []
            
            for temp_x,temp_y in data:
                count+=1
                curr_x = temp_x.copy()
                curr_y = temp_y.copy()
                
                word_encodings = []
                for dic in curr_x:
                    word_encodings.append(self.transform_words(dic))
                curr_x = np.array(word_encodings)

    
                curr_x = curr_x.T
                curr_y = curr_y.T
                y_hat = self.forward(curr_x)            
                
#                 print("curr_y[0]: {}; y_hat[0]: {}".format(curr_y[0], y_hat[0]))
                dl_dyhat = self.imp_focal_loss_sum(curr_y,y_hat)

                self.backward(1)
                
                
                losses.append(dl_dyhat)
                if j == no_of_batches_train-1:
                    print("lossses: {}".format(np.array(losses)))
                    print("losses sum: {}".format(sum(losses)))
                    print("losses length: {}".format(len(losses)))

                    loss = sum(losses) / len(losses)
                    print()
                    print("loss: {}....".format(loss))

                if batch_size == 1:
                    N = train_data[0].shape[0]
                else:
                    N = curr_x.shape[-1]
                
                #updating the weights using ADAM optimizer
                beta1= 0.9
                beta2= 0.999 #best values for betas as towardsdatascience artice discussed
                for i in range(len(self.layers)):
                    m[i][0] = beta1 * m[i][0] + (1-beta1) * self.layers[i].dW
                    m[i][1] = beta1 * m[i][1] + (1-beta1) * self.layers[i].db

                    v[i][0] = beta2 * v[i][0] + (1-beta2) * np.square(self.layers[i].dW)
                    v[i][1] = beta2 * v[i][1] + (1-beta2) * np.square(self.layers[i].db)

                    deltaW = (-1 * self.learning_rate * m[i][0]) / (np.sqrt(v[i][0] + 0.001))
                    deltab = (-1 * self.learning_rate * m[i][1]) / (np.sqrt(v[i][1] + 0.001))

                    self.layers[i].W = self.layers[i].W + deltaW/N
                    self.layers[i].b = self.layers[i].b + deltab/N
                self.zeroing()
                j += 1 
#                 print("Reached here")
            

    def predict(self,data):
        
        word_encodings = []
        for dic in data:
            word_encodings.append(self.transform_words(dic))
        words = np.array(word_encodings)

        
        y_hat= self.forward(words.T)
        return y_hat.T
# In[344]:


print(len(encoded_words))


# In[345]:




# In[346]:




