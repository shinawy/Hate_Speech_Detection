from distutils.command.clean import clean
from multiprocessing.dummy import current_process
from django.shortcuts import render, redirect
from django.urls import reverse
import numpy as np
import ast
import pandas as pd
import json
from apps.research import train_nn


def update_dataset(clean_data, label):
    filename= r'''E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\backend\server\apps\research\{}'''.format("final_cleaned_data.csv")
    df= pd.DataFrame([[label,"",clean_data, ""]], columns= ["hatespeech","text","preprocess_data","word_tfidf"])
    # print(df)
    df.to_csv(filename, mode='a', header=False)

def update_count_file():
    try:
        filename= r'''E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\backend\server\apps\research\{}'''.format("count.txt")
        print("updating the count file...")
        with open(filename, 'r+',encoding='utf-8') as fhandle:
            fhandle.seek(0)
            curr_count= fhandle.read()
            print(curr_count)
            new_count= int(curr_count)+1
            fhandle.seek(0)
            fhandle.truncate()
            if new_count==10: # 10 instances were added to the dataset
                nn_model= train_nn.train_save_nn()
                fhandle.write("0")
            else:
                fhandle.write(str(new_count))
                
        fhandle.close()

    except:
        filename= r'''E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\backend\server\apps\research\{}'''.format("count.txt")
        print("creating the count file as it does not exist")
        with open(filename, 'w',encoding='utf-8') as fhandle:
            fhandle.write("0")
        fhandle.close()

def update_encoded_dict(clean_data):
    filename= r'''E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\backend\server\apps\research\{}'''.format("freq_dic_encoded.txt")
    print("updating the encoded dictionary.....")
    with open(filename, 'r+',encoding='utf-8') as fhandle:
        encoded_dict= json.load(fhandle)
        for word in clean_data:
            if word not in encoded_dict.keys():
                encoded_dict[word]= len(encoded_dict.keys())
        fhandle.seek(0)
        fhandle.truncate()
        json.dump(encoded_dict, fhandle)
        
    fhandle.close()

def online_train(clean_data, label): 
    print("starting the online train process")
    update_dataset(clean_data, label)
    update_count_file()
    update_encoded_dict(clean_data)

    



# Create your views here.
# backend/server/apps/endpoints/views.py file
from rest_framework import viewsets
from rest_framework import mixins

from apps.endpoints.models import Endpoint
from apps.endpoints.serializers import EndpointSerializer

from apps.endpoints.models import MLAlgorithm
from apps.endpoints.serializers import MLAlgorithmSerializer

from apps.endpoints.models import MLAlgorithmStatus
from apps.endpoints.serializers import MLAlgorithmStatusSerializer

from apps.endpoints.models import MLRequest
from apps.endpoints.serializers import MLRequestSerializer

class EndpointViewSet(
    mixins.RetrieveModelMixin, mixins.ListModelMixin, viewsets.GenericViewSet
):
    serializer_class = EndpointSerializer
    queryset = Endpoint.objects.all()


class MLAlgorithmViewSet(
    mixins.RetrieveModelMixin, mixins.ListModelMixin, viewsets.GenericViewSet
):
    serializer_class = MLAlgorithmSerializer
    queryset = MLAlgorithm.objects.all()


def deactivate_other_statuses(instance):
    old_statuses = MLAlgorithmStatus.objects.filter(parent_mlalgorithm = instance.parent_mlalgorithm,
                                                        created_at__lt=instance.created_at,
                                                        active=True)
    for i in range(len(old_statuses)):
        old_statuses[i].active = False
    MLAlgorithmStatus.objects.bulk_update(old_statuses, ["active"])

class MLAlgorithmStatusViewSet(
    mixins.RetrieveModelMixin, mixins.ListModelMixin, viewsets.GenericViewSet,
    mixins.CreateModelMixin
):
    serializer_class = MLAlgorithmStatusSerializer
    queryset = MLAlgorithmStatus.objects.all()
    def perform_create(self, serializer):
        try:
            with transaction.atomic():
                instance = serializer.save(active=True)
                # set active=False for other statuses
                deactivate_other_statuses(instance)



        except Exception as e:
            raise APIException(str(e))

class MLRequestViewSet(
    mixins.RetrieveModelMixin, mixins.ListModelMixin, viewsets.GenericViewSet,
    mixins.UpdateModelMixin
):
    serializer_class = MLRequestSerializer
    queryset = MLRequest.objects.all()

    # please add imports
import json
from numpy.random import rand
from rest_framework import views, status
from rest_framework.response import Response
from apps.ml.registry import MLRegistry
from server.wsgi import registry
from apps.ml.income_classifier import neural_network


'''
... the rest of the backend/server/apps/endpoints/views.py file ...
'''


class PredictView(views.APIView):
    def serve_req(self, request, format=None):
        
        algorithm_object = neural_network.NeuralNetwork()
        req_data= request.data
        print("data is ::: ", req_data)
        
        prediction = algorithm_object.compute_prediction(request.data['query'])
        
        

        label = prediction["label"] if "label" in prediction else "error"
        

        return render(request, 'predict.html')


def serve_req_out( request):
        
    if request.method == "GET":
        algorithm_object = neural_network.NeuralNetwork()
        query = request.GET.get('input')
        prediction = algorithm_object.compute_prediction(query)
        query=str(query)
        cleaned_data= algorithm_object.preprocessing_for_requests(query)

        with open(r'''E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\backend\server\apps\research\req_data.txt''', 'w') as fhandle:
            fhandle.write(str(cleaned_data["clean_data"]))
        fhandle.close()
        label = prediction["label"] if "label" in prediction else "error"
        if (label == 1):
            return redirect('hatespeech_page')
        elif (label == 0):
            return redirect('nothatespeech_page')

        else: 
            return render(request, 'predict.html')
        # str= "label: {}, data:{}".format(label, query)
        # json_dic= {"inp": str}
        # return render(request, 'predict.html',json_dic)

    else: 
         return render(request, 'predict.html', {"inp": "shinawy"})
    
    # if request.method == "POST":
    #     query = request.POST.get('input')
    
    

    
    
    # return render(request, 'predict.html', json_dic)

def hatespeech_page( request):
        
        
    if request.method == "GET":
        filename= r'''E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\backend\server\apps\research\{}'''.format("req_data.txt")
        with open(filename, 'r') as fhandle:
            req_data= fhandle.read()
        fhandle.close()
        feedback = request.GET.get('input')
        json_dic= {"inp": feedback}

        if feedback is not None:
            online_train(ast.literal_eval(req_data), feedback)
        return render(request, 'hate.html', json_dic)
    
    else:
         return render(request, 'hate.html')
    
    
    # do  some logic


    
    

    return render(request, 'hate.html')

def nothatespeech_page( request, format=None):
        
    #  return render(request, 'nothate.html')
    if request.method == "GET":

        filename= r'''E:\The American University in Cairo\Spring 2022\Introduction to Machine Learning\Project\Phase 5 - Model Implementation\machine_app_util\backend\server\apps\research\{}'''.format("req_data.txt")
        with open(filename, 'r') as fhandle:
            req_data= fhandle.read()
        fhandle.close()
        feedback = request.GET.get('input')
        json_dic= {"inp":  req_data}
        if feedback is not None:
            online_train(ast.literal_eval(req_data), feedback)
        return render(request, 'nothate.html', json_dic)
    
    else:
         return render(request, 'nothate.html')
    # do  some logic


    
    
    