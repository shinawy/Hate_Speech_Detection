# backend/server/apps/endpoints/urls.py file
from django.urls import re_path, include
from rest_framework.routers import DefaultRouter

from apps.endpoints.views import EndpointViewSet
from apps.endpoints.views import MLAlgorithmViewSet
from apps.endpoints.views import MLAlgorithmStatusViewSet
from apps.endpoints.views import MLRequestViewSet
from apps.endpoints.views import PredictView # import PredictView
from . import views

router = DefaultRouter(trailing_slash=False)
router.register(r"endpoints", EndpointViewSet, basename="endpoints")
router.register(r"mlalgorithms", MLAlgorithmViewSet, basename="mlalgorithms")
router.register(r"mlalgorithmstatuses", MLAlgorithmStatusViewSet, basename="mlalgorithmstatuses")
router.register(r"mlrequests", MLRequestViewSet, basename="mlrequests")
# router.register(r"hate_prediction", PredictView, basename="hate_predict")  
  
app_name = "endpoints"

urlpatterns = [
    re_path(r"^api/v1/", include(router.urls)),
    # add predict url
    re_path(
 
        r"^api/v1/neural_network/predict$", views.serve_req_out, name="serve_endpoint"
    ), 
    re_path(
 
        r"^api/v1/neural_network/predict/hate$", views.hatespeech_page, name="hatespeech_page"
    ), 
    re_path(
 
        r"^api/v1/neural_network/predict/nothate$", views.nothatespeech_page, name="nothatespeech_page"
    ), 
    re_path(

      r"^api/v1/(?P<endpoint_name>.+)/predict$", views.serve_req_out, name="serve_end_point2"

    )
] 